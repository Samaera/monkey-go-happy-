 var monkey , monkey_running;
var banana ,bananaimage, obstacle, obstacleimage;
var FoodGroup, obstacleGroup;
var ground;
var score=0;
var survivalTime=0;
function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaimage = loadImage("banana.png");
  obstacleimage = loadImage("obstacle.png");
 
}


function setup() {
  createCanvas(400,355);
  monkey=createSprite(80,315,20,20);
  monkey.addAnimation("moving",monkey_running)
  monkey.scale=0.1;
  
  ground=createSprite(700,350,1600,10);
  ground.velocityX=-4;
  ground.x=ground.width/2;
  console.log(ground.x);
  
  FoodGroup = new Group();
  obstacleGroup = new Group();
  
}


function draw() {
background("lime");
  
  stroke("black");
  textSize(20);
  fill("Black");
  survivalTime=Math.ceil(frameCount/frameRate())
 // text("SurvivalTime:" ,100,50)
  if(keyDown("space")){
    monkey.velocityY=-13;
  }
  if(FoodGroup.isTouching(monkey)){
    score=score+1;
    FoodGroup.destroyEach();
  }
  switch(score){
    case 10 : monkey.scale=0.12;
    break;
    case 20 : monkey.scale=0.14;
    break;
    case 30 : monkey.scale=0.16;
    break;
    case 40 : monkey.scale=0.18;
    break;
    default:break;
  }
  if(obstacleGroup.isTouching(monkey)){
    monkey.scale=0.2;
  }
  monkey.velocityY= monkey.velocityY+0.8;
  if(ground.x<0){
    ground.x=ground.width/2;
  }
  monkey.collide(ground);
  Food();
  obstacles();
  drawSprites();
  stroke("white");
  textSize(20);
  fill("white");
  text("Score:"+score,250,50);
}
function Food(){
  if(World.frameCount%80===0){
     banana=createSprite(500,random(120,200),10,10);
     banana.addImage(bananaimage);
     banana.velocityX=-3;
     banana.lifetime=180;
     banana.scale=0.1;
     FoodGroup.add(banana); 
     
     }
}
function obstacles(){
  if(World.frameCount%300===0){
     obstacle=createSprite(550,320,10,10);
     obstacle.addImage(obstacleimage);
     obstacle.velocityX=-3;
     obstacle.lifetime=180;
     obstacle.scale=0.1;
     obstacleGroup.add(obstacle);
     
     }
}